<?php
/** Pangasinan (Pangasinan)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Arikasikis
 * @author Spacebirdy
 */

$messages = array(
# User preference toggles
'tog-enotifwatchlistpages' => 'Manpa-awit na e-mail ed siak no abalo may sakey ya bolong ya babantayan ko',

'underline-always' => 'Naynay',
'underline-never'  => 'Andin-balot',

# Categories related messages
'category_header' => 'Saray artikulo ed category ya "$1"',

'about'    => 'Nipakar ed',
'article'  => 'Bolong na laman',
'cancel'   => 'I-tonda',
'mypage'   => 'Say bolong ko',
'mytalk'   => 'Say tongtongan ko',
'anontalk' => 'Tongtongan para ed sayan IP',
'and'      => '&#32;san',

# Cologne Blue skin
'qbpageoptions'  => 'Ayan bolong',
'qbspecialpages' => 'Niduma ran Bolobolong',

'returnto'          => 'Impawel ed $1.',
'help'              => 'Tolong',
'search'            => 'Anapen',
'searchbutton'      => 'Anapen',
'go'                => 'Ula',
'searcharticle'     => 'Ula',
'history'           => 'Awaran na sayan bolong',
'history_short'     => 'awaran na sayan bolong',
'printableversion'  => 'Naigalot ya bersion',
'permalink'         => 'Masiansian gawing',
'edit'              => 'Baloen o dagdagan',
'delete'            => 'Buralen',
'deletethispage'    => 'Buralen so ayan page',
'protect'           => 'Iyagel',
'protectthispage'   => 'Iyagel yan bolong',
'unprotect'         => 'aga la iyagel',
'unprotectthispage' => 'Aga la iyagel yan bolong',
'newpage'           => 'Balon bolong',
'talkpage'          => 'Pantongtongan yan bolong',
'specialpage'       => 'Niduman Bolong',
'articlepage'       => 'Nengnengen so content page',
'talk'              => 'Tongtongan',
'userpage'          => 'Basaen so bolong na manag-usar',
'mediawikipage'     => 'Nengnengen so bolong na pakabat',
'viewhelppage'      => 'Nengnengen so bolong na tolong',
'categorypage'      => 'Nengnengen so bolong na saray category',
'viewtalkpage'      => 'Nengnengen so tongtongan',
'otherlanguages'    => 'Diad arom ran salita',
'lastmodifiedat'    => 'Say ayan bolong: otet ya binalo nen $2, $1.',
'protectedpage'     => 'Iyayagel yan bolong',
'jumptosearch'      => 'anapen',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'aboutsite'            => 'Nipakar ed {{SITENAME}}',
'aboutpage'            => 'Project:Nipaakar',
'currentevents'        => 'Saray nagagawa natan',
'currentevents-url'    => 'Project:Saray nagagawa natan',
'edithelp'             => 'Tolong nipakar ed panagbalo na artikulo',
'helppage'             => 'Help:Saray Laman',
'mainpage'             => 'Arapan ya Bolong',
'mainpage-description' => 'Arapan ya Bolong',
'portal'               => 'Pwerta na komyunidad',
'portal-url'           => 'Project:Pwerta na Komyunidad',

'badaccess-group0' => 'Agmo sarag ya gaween so action ya kekerewen mo.',

'youhavenewmessages'      => 'Walay $1 ($2).',
'newmessageslink'         => 'balo ran pakabat',
'newmessagesdifflink'     => 'sampot ya binalo',
'youhavenewmessagesmulti' => 'Walay balo ran pakabat mo ed $1',
'viewdeleted'             => 'Nengnengen so $1?',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-user'      => 'Bolong na manag-usar',
'nstab-mediawiki' => 'Pakabat',

# General errors
'badarticleerror' => 'Aga sarag ya gaween so ayan action ed sayan bolong.',
'cannotdelete'    => 'Aga nabural so nibagan bolong o file. (Sarag ton abural la na arom.)',
'badtitle'        => 'Aga sarag ya titulo',
'viewsource'      => 'Nengnengen so pinanlapuan',
'viewsourcefor'   => 'para $1',
'viewsourcetext'  => 'Sarag mon nengnengen san kopyaen so pinanlapuan na ayan bolong:',

# Login and logout pages
'yourdomainname'             => 'Say domain mo',
'login'                      => 'Onloob',
'logout'                     => 'Paway',
'userlogout'                 => 'Paway',
'createaccount'              => 'Mangawa na account',
'gotaccountlink'             => 'Onloob',
'badretype'                  => 'Aga parehas so en-type mo ran password.',
'acct_creation_throttle_hit' => 'Sorry, nangawala ka la na $1 account. Agka la makapangawa na account.',
'accountcreated'             => 'Agawa so account',
'accountcreatedtext'         => 'Agawa la so user account para $1.',

# Password reset dialog
'newpassword' => 'Balon password:',

# Edit page toolbar
'link_tip' => 'Gawing ed loob',

# Edit pages
'minoredit'             => 'Melag yan edit.',
'watchthis'             => 'Bantayan yan bolong',
'preview'               => 'Nengnengen',
'showdiff'              => 'Ipanengneng so binalo',
'anoneditwarning'       => "'''Pasakbay:''' Agka ni limmoob. Aka-record so IP address mo ed agawgawa ed bolong.",
'blockedtitle'          => 'Sebel ed sayan manag-usar',
'blockednoreason'       => 'anggapon katunungan so inter',
'blockedoriginalsource' => "Wadyad leksab so pinanlapuan na '''$1''':",
'blockededitsource'     => "Wadyad leksab so text na '''saray binalom''' anggag '''$1''':",
'whitelistedittitle'    => 'Nakaukulan ya onloob umpian makapanbalo',
'whitelistedittext'     => 'Nakaukulan mo ya $1 umpian nabalo o nadagdagan ray bolobolong.',
'loginreqtitle'         => 'Nakaukulan kan Onloob',
'loginreqlink'          => 'onloob',
'loginreqpagetext'      => 'Nakaukulan kan $1 umpian nanengneng so arom ran bolobolong.',
'accmailtitle'          => 'Say Password impawet la.',
'accmailtext'           => 'Empawet ed $2 so password para ed $1.',
'newarticle'            => '(Balo)',
'editing'               => 'Babaloen so $1',
'yourdiff'              => 'Saray niduma',
'copyrightwarning'      => "Tandaan komon ya amin ya contribution para ed {{SITENAME}} et nonoten ya pinaolian onong ed $2 (nengnengen so $1 para ed detalye).
No ag mo labay ya say inkorit mo ed sarag ya baloen odino ibonog ed anggan siopa, ag mo ipapalima dia.<br />
San ipropromisam met ya insulat mo yan dili o kinopyam ya manlapo ed sakey ya public domain odino parehas ya libren resource.
'''AG MANPALIMA NA KIMEY YA WALAY COPYRIGHT TO YA ANGGAPOY ABOLOY!'''",

# Account creation failure
'cantcreateaccounttitle' => 'Aga makagawa na account',

# History pages
'last'      => 'sampot',
'histfirst' => 'Sankaunaan',
'histlast'  => 'Sankautetan',

# Diffs
'difference' => '(Say niduma diad saray revision)',

# Search results
'searchsubtitle'        => "'''[[:$1]]''' so inanap mo.",
'searchsubtitleinvalid' => "'''$1''' so inanap mo.",
'searchhelp-url'        => 'Help:Saray Laman',
'powersearch'           => 'Anapen',

# Quickbar
'qbsettings-none' => 'Anggapo',

# Preferences page
'mypreferences'     => 'Saray preference ko',
'changepassword'    => 'Salatan so password',
'datedefault'       => 'Anggapoy preference',
'prefs-datetime'    => 'Bilang na agew san oras',
'prefs-rc'          => 'Sampot ran binalo',
'prefs-watchlist'   => 'Listaan na babantayan',
'prefs-editing'     => 'Babaloen',
'searchresultshead' => 'Anapen',
'yourrealname'      => 'Tuwan ngaran:',
'badsiglength'      => 'Andukey ya maong so nickname. Say dukey to dapat mas daiset en say $1 ya character.',

# User rights
'userrights-user-editname' => 'Isulat so username:',

# Recent changes
'recentchanges' => 'Sampot ran binalo',
'hide'          => 'Yamot',
'show'          => 'Ipanengneng',

# Recent changes linked
'recentchangeslinked'         => 'Kabiangan ran binalo',
'recentchangeslinked-feed'    => 'Kabiangan ran binalo',
'recentchangeslinked-toolbox' => 'Kabiangan ran binalo',

# Upload
'upload'          => 'Mangisigep na file',
'uploadlog'       => 'Isigep so log',
'filesource'      => 'Pinanlapuan:',
'uploadedfiles'   => 'Insegep ran file',
'badfilename'     => 'Binalo so ngaran na file, umpian "$1" so balon ngaran to.',
'sourcefilename'  => 'Filename na pinanlapuan:',
'watchthisupload' => 'Bantayan yan bolong',

# Special:ListFiles
'listfiles_name' => 'Ngaran',

# File description page
'imagelinks' => 'Saray Gawing',

# MIME search
'download' => 'mangileksab (download)',

# Unused templates
'unusedtemplateswlh' => 'arom ran gawing',

# Random page
'randompage'         => 'Random ya bolong',
'randompage-nopages' => 'Anggapoy bolong ya wadya ed ayan namespace.',

'withoutinterwiki'         => 'Saray bolobolong ya anggapoy gawing ya language',
'withoutinterwiki-summary' => 'Anggapoy gawin paulad version na arum ran salita so ontombok ran bolobolong:',

# Miscellaneous special pages
'shortpages'     => 'Antikey ran bolong',
'longpages'      => 'Andokoy ran bolong',
'protectedpages' => 'Iyayagel ran bolobolong',
'newpages'       => 'Balo ran bolong',
'ancientpages'   => 'Sankadaanan ran bolobolong',
'move'           => 'Iyales',
'movethispage'   => 'Iyales yan bolong',

# Book sources
'booksources'               => 'Saray liblibron pinanlapuan',
'booksources-search-legend' => 'Mananap na saray libron pinanlapuan',
'booksources-go'            => 'Ula',

# Special:Log
'all-logs-page' => 'Amin ran log',

# Special:AllPages
'allpages'          => 'Amin ya bolobolong',
'alphaindexline'    => '$1 anggad $2',
'nextpage'          => 'Ontombok ya page ($1)',
'allpagesfrom'      => 'Ipanengneng ray bolobolong ya manlapod:',
'allarticles'       => 'Amin ran bolobolong',
'allinnamespace'    => 'Amin ya bolobolong ($1 namespace)',
'allnotinnamespace' => 'Amin ya bolobolong (anggapo ed namespace ya $1)',
'allpagesprev'      => 'Enbeneg',
'allpagesnext'      => 'Ontombok',
'allpagessubmit'    => 'Ula',
'allpagesprefix'    => 'Ipanengneng so saray bolobolong ya walay prefix:',

# Special:LinkSearch
'linksearch'     => 'Anapen ramay gawing ed web',
'linksearch-pat' => 'Anapen so pattern:',
'linksearch-ok'  => 'Anapen',

# Special:Log/newusers
'newuserlog-create-entry' => 'Balon user',

# E-mail user
'emailuser'     => 'E-mail so ayan user',
'emailfrom'     => 'Manlapud',
'emailto'       => 'Para ed',
'emailmessage'  => 'Pakabat',
'emailsend'     => 'Paawit',
'emailsent'     => 'Say e-mail impawet la',
'emailsenttext' => 'Impawit la so e-mail message mo.',

# Watchlist
'mywatchlist'    => 'Listaan na babantayan ko',
'watchnologin'   => 'Agka ni akaloob',
'addedwatch'     => 'Enyarom ed listaan na bantayan',
'addedwatchtext' => "Impila so bolong ya \"[[:\$1]]\" diad [[Special:Watchlist|listaan na babantayan]] mo. Isulat diman so saray ontombok ran idagdag o panagbalo ed sayan bolong san diad bolong na tongtongan. San akasulat ran '''mapatnag''' (bolded) ed [[Special:RecentChanges|listaan na saray sampot ran binalo]] umpian mas maganom ya nanengneng.

No labay mon ekalen may bolong diad listaan na babantayan, tapik mo labat so \"ekalen ed babantayan\" (unwatch) diad gilig ya bar.",
'watch'          => 'bantayan',
'watchthispage'  => 'Bantayan yan bolong',

# Displayed when you click the "watch" button and it is in the process of watching
'watching' => 'Babantayan...',

'enotif_newpagetext' => 'Balo yan bolong.',
'changed'            => 'asalatan',
'created'            => 'agawa',

# Delete
'deletepage'     => 'Buralen so bolong',
'confirm'        => 'Paletan',
'exblank'        => 'Anggapoy laman na bolong',
'actioncomplete' => 'Asumpal lan agawa',
'deletedtext'    => 'Abural lay "<nowiki>$1</nowiki>".
Pinengneng so $2 para ed listaan na saray abural ran balo.',
'deletedarticle' => 'binural so "[[$1]]"',
'deletecomment'  => 'Katonongan',

# Protect
'prot_1movedto2'      => 'say [[$1]] enyales paula ed [[$2]]',
'protect-legend'      => 'Palitaen so pangiyagel',
'protect-level-sysop' => 'Sysops labat',

# Undelete
'undelete'               => 'Nengnengen so inekal ran bolobolong',
'viewdeletedpage'        => 'Nengnengen so inekal ran bolong',
'undelete-search-box'    => 'Anapen ramay binural ran bolobolong',
'undelete-search-prefix' => 'Ipanengneng ray bolobolong ya mangagapo ed:',
'undelete-search-submit' => 'Anapen',

# Contributions
'contributions' => 'Saray contribution na user',
'mycontris'     => 'Saray entolong ko',
'year'          => 'Taon:',

'sp-contributions-newbies-sub' => 'Para balo ran account',
'sp-contributions-submit'      => 'Anapen',

# What links here
'whatlinkshere'       => 'Antoray akaturo dia',
'whatlinkshere-title' => 'Saray bolong ya aka-gawing ed $1',
'whatlinkshere-page'  => 'Bolong:',

# Block/unblock
'blockip'            => 'Isara ed para ayan manag-usar',
'ipbreason'          => 'Katonongan',
'ipbreasonotherlist' => 'Arom ya katonongan',
'ipbsubmit'          => 'Isebel ed sayan manag-usar',
'badipaddress'       => 'Aga nayarin IP address',
'ipusubmit'          => 'Aga la isebel so ayan address',
'ipblocklist'        => 'Listaan na saray sebel ran IP address san username',
'ipblocklist-submit' => 'Anapen',
'expiringblock'      => 'nabalang no $1 $2',
'blocklink'          => 'isara',
'contribslink'       => 'saray entolong to',

# Move page
'move-page-legend'        => 'Iyales so bolong',
'movearticle'             => 'Iyales so bolong',
'movepagebtn'             => 'Iyales so bolong',
'pagemovedsub'            => 'Asumpal lan inyales',
'articleexists'           => 'Wala lay bolong to may ngaran ya atan, odino aga valid so pinilim ya ngaran. Pili ka pa na arom ya ngaran.',
'1movedto2'               => 'say [[$1]] enyales paula ed [[$2]]',
'movereason'              => 'Katonongan',
'delete_and_move'         => 'Buralen san iyales',
'delete_and_move_confirm' => 'On, buralen yan page',

# Export
'export-submit' => 'Ipaawit',
'export-addcat' => 'Iyarom',

# Namespace 8 related
'allmessages'     => 'Saray pakabat na oksoy',
'allmessagesname' => 'Ngaran',
'allmessagestext' => 'Aya so listaan na amin ya pakabat na oksoy ya naanap ed MediaWiki namespace.',

# Thumbnails
'filemissing' => 'Nababalang so file',

# Special:Import
'importnotext' => 'Andilugan odino anggapoy laman ton text',

# Tooltip help for the actions
'tooltip-pt-logout'          => 'Paway',
'tooltip-ca-viewsource'      => 'Iya-yagel yan bolong. Sarag mon nengnengen so pinanlapuan to.',
'tooltip-ca-protect'         => 'Iyagel yan bolong',
'tooltip-ca-move'            => 'Iyales so ayan bolong',
'tooltip-search'             => 'Anapen {{SITENAME}}',
'tooltip-p-logo'             => 'Arapan ya Bolong',
'tooltip-t-specialpages'     => 'Listaan na amin ran niduman bolobolong',
'tooltip-ca-nstab-user'      => 'Nengnengen so bolong na manag-usar',
'tooltip-ca-nstab-mediawiki' => 'Nengnengen so pakabat na oksoy',

# Attribution
'lastmodifiedatby' => 'Sampot ya binalo yan bolong nen agew ya $2, $1 nen $3.',

# Math errors
'math_unknown_error' => 'aga-antan error',

# Special:NewFiles
'ilsubmit' => 'Anapen',

# EXIF tags
'exif-filesource' => 'File na pinanlapuan',

# 'all' in various places, this might be different for inflected languages
'imagelistall'  => 'amin',
'watchlistall2' => 'amin',
'namespacesall' => 'amin',
'monthsall'     => 'amin',

# E-mail address confirmation
'confirmemail'           => 'Kumpirmaen so E-mail address',
'confirmemail_sent'      => 'Empawet so confirmation e-mail.',
'confirmemail_needlogin' => 'Nakaukulan mo ya $1 umpian nakompirma so email address mo.',
'confirmemail_success'   => 'Akompirma so e-mail address mo. Sarag mo lay man-log-in san panliketan so wiki.',
'confirmemail_loggedin'  => 'Akompira la so e-mail address mo.',

# Delete conflict
'deletedwhileediting' => 'Pasakbay: Abural yan bolong nen ginapuan mon baloen!',

# action=purge
'confirm-purge-top' => 'Ekalen so cache na sayan bolong?',

# Multipage image navigation
'imgmultipagenext' => 'ontombok ya bolong →',
'imgmultigo'       => 'Ula!',

# Table pager
'table_pager_next'         => 'Ontombok ya bolong',
'table_pager_prev'         => 'Embeneg ya bolong',
'table_pager_first'        => 'Unaan ya bolong',
'table_pager_last'         => 'Otet ya bolong',
'table_pager_limit_submit' => 'Ula',

# Auto-summaries
'autosumm-blank'   => 'Ekalen so amin ya laman na bolong',
'autosumm-replace' => "Salatan yan bolong na '$1'",
'autoredircomment' => 'Ituturo paulad [[$1]]',
'autosumm-new'     => 'Balon bolong: $1',

# Live preview
'livepreview-loading' => 'Ilulugan…',
'livepreview-ready'   => 'Ilulugan… Akaparaan!',

# Special:SpecialPages
'specialpages' => 'Niduma ran bolobolong',

);
